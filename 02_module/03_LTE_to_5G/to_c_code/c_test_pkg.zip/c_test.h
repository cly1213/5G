/*
 * File: c_test.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 25-May-2021 16:21:40
 */

#ifndef C_TEST_H
#define C_TEST_H

/* Include Files */
#include "c_test_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void c_test(const emxArray_int8_T *trBlk, double trBlkLen,
                   emxArray_int8_T *decbits);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for c_test.h
 *
 * [EOF]
 */
