/*
 * File: c_test_data.c
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 25-May-2021 16:21:40
 */

/* Include Files */
#include "c_test_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
const signed char iv[25] = {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                            0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1};

const char cv[128] = {
    '\x00',     '\x01', '\x02', '\x03', '\x04', '\x05', '\x06', '\x07', '\x08',
    '	', '\x0a', '\x0b', '\x0c', '\x0d', '\x0e', '\x0f', '\x10', '\x11',
    '\x12',     '\x13', '\x14', '\x15', '\x16', '\x17', '\x18', '\x19', '\x1a',
    '\x1b',     '\x1c', '\x1d', '\x1e', '\x1f', ' ',    '!',    '\"',   '#',
    '$',        '%',    '&',    '\'',   '(',    ')',    '*',    '+',    ',',
    '-',        '.',    '/',    '0',    '1',    '2',    '3',    '4',    '5',
    '6',        '7',    '8',    '9',    ':',    ';',    '<',    '=',    '>',
    '?',        '@',    'a',    'b',    'c',    'd',    'e',    'f',    'g',
    'h',        'i',    'j',    'k',    'l',    'm',    'n',    'o',    'p',
    'q',        'r',    's',    't',    'u',    'v',    'w',    'x',    'y',
    'z',        '[',    '\\',   ']',    '^',    '_',    '`',    'a',    'b',
    'c',        'd',    'e',    'f',    'g',    'h',    'i',    'j',    'k',
    'l',        'm',    'n',    'o',    'p',    'q',    'r',    's',    't',
    'u',        'v',    'w',    'x',    'y',    'z',    '{',    '|',    '}',
    '~',        '\x7f'};

boolean_T isInitialized_c_test = false;

/*
 * File trailer for c_test_data.c
 *
 * [EOF]
 */
