/*
 * File: c_test_initialize.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 25-May-2021 16:21:40
 */

#ifndef C_TEST_INITIALIZE_H
#define C_TEST_INITIALIZE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void c_test_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for c_test_initialize.h
 *
 * [EOF]
 */
