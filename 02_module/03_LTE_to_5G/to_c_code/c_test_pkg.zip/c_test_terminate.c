/*
 * File: c_test_terminate.c
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 25-May-2021 16:21:40
 */

/* Include Files */
#include "c_test_terminate.h"
#include "c_test_data.h"
#include "getParams.h"
#include "rt_nonfinite.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void c_test_terminate(void)
{
  d_2_240params_free();
  d_2_120params_free();
  d_2_60params_free();
  d_2_30params_free();
  d_2_15params_free();
  d_2_208params_free();
  d_2_104params_free();
  d_2_52params_free();
  d_2_26params_free();
  d_2_13params_free();
  d_2_352params_free();
  d_2_176params_free();
  d_2_88params_free();
  d_2_44params_free();
  d_2_22params_free();
  d_2_11params_free();
  d_2_288params_free();
  d_2_144params_free();
  d_2_72params_free();
  d_2_36params_free();
  d_2_18params_free();
  d_2_9params_free();
  d_2_224params_free();
  d_2_112params_free();
  d_2_56params_free();
  d_2_28params_free();
  d_2_14params_free();
  d_2_7params_free();
  d_2_320params_free();
  d_2_160params_free();
  d_2_80params_free();
  d_2_40params_free();
  d_2_20params_free();
  d_2_10params_free();
  d_2_5params_free();
  d_2_384params_free();
  d_2_192params_free();
  d_2_96params_free();
  d_2_48params_free();
  d_2_24params_free();
  d_2_12params_free();
  d_2_6params_free();
  d_2_3params_free();
  d_2_256params_free();
  d_2_128params_free();
  d_2_64params_free();
  d_2_32params_free();
  d_2_16params_free();
  d_2_8params_free();
  d_2_4params_free();
  d_2_2params_free();
  d_1_240params_free();
  d_1_120params_free();
  d_1_60params_free();
  d_1_30params_free();
  d_1_15params_free();
  d_1_208params_free();
  d_1_104params_free();
  d_1_52params_free();
  d_1_26params_free();
  d_1_13params_free();
  d_1_352params_free();
  d_1_176params_free();
  d_1_88params_free();
  d_1_44params_free();
  d_1_22params_free();
  d_1_11params_free();
  d_1_288params_free();
  d_1_144params_free();
  d_1_72params_free();
  d_1_36params_free();
  d_1_18params_free();
  d_1_9params_free();
  d_1_224params_free();
  d_1_112params_free();
  d_1_56params_free();
  d_1_28params_free();
  d_1_14params_free();
  d_1_7params_free();
  d_1_320params_free();
  d_1_160params_free();
  d_1_80params_free();
  d_1_40params_free();
  d_1_20params_free();
  d_1_10params_free();
  d_1_5params_free();
  d_1_384params_free();
  d_1_192params_free();
  d_1_96params_free();
  d_1_48params_free();
  d_1_24params_free();
  d_1_12params_free();
  d_1_6params_free();
  d_1_3params_free();
  d_1_256params_free();
  d_1_128params_free();
  d_1_64params_free();
  d_1_32params_free();
  d_1_16params_free();
  d_1_8params_free();
  d_1_4params_free();
  d_1_2params_free();
  isInitialized_c_test = false;
}

/*
 * File trailer for c_test_terminate.c
 *
 * [EOF]
 */
