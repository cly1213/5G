/*
 * File: getParams.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 25-May-2021 16:21:40
 */

#ifndef GETPARAMS_H
#define GETPARAMS_H

/* Include Files */
#include "c_test_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void d_1_104params_free(void);

void d_1_104params_init(void);

void d_1_10params_free(void);

void d_1_10params_init(void);

void d_1_112params_free(void);

void d_1_112params_init(void);

void d_1_11params_free(void);

void d_1_11params_init(void);

void d_1_120params_free(void);

void d_1_120params_init(void);

void d_1_128params_free(void);

void d_1_128params_init(void);

void d_1_12params_free(void);

void d_1_12params_init(void);

void d_1_13params_free(void);

void d_1_13params_init(void);

void d_1_144params_free(void);

void d_1_144params_init(void);

void d_1_14params_free(void);

void d_1_14params_init(void);

void d_1_15params_free(void);

void d_1_15params_init(void);

void d_1_160params_free(void);

void d_1_160params_init(void);

void d_1_16params_free(void);

void d_1_16params_init(void);

void d_1_176params_free(void);

void d_1_176params_init(void);

void d_1_18params_free(void);

void d_1_18params_init(void);

void d_1_192params_free(void);

void d_1_192params_init(void);

void d_1_208params_free(void);

void d_1_208params_init(void);

void d_1_20params_free(void);

void d_1_20params_init(void);

void d_1_224params_free(void);

void d_1_224params_init(void);

void d_1_22params_free(void);

void d_1_22params_init(void);

void d_1_240params_free(void);

void d_1_240params_init(void);

void d_1_24params_free(void);

void d_1_24params_init(void);

void d_1_256params_free(void);

void d_1_256params_init(void);

void d_1_26params_free(void);

void d_1_26params_init(void);

void d_1_288params_free(void);

void d_1_288params_init(void);

void d_1_28params_free(void);

void d_1_28params_init(void);

void d_1_2params_free(void);

void d_1_2params_init(void);

void d_1_30params_free(void);

void d_1_30params_init(void);

void d_1_320params_free(void);

void d_1_320params_init(void);

void d_1_32params_free(void);

void d_1_32params_init(void);

void d_1_352params_free(void);

void d_1_352params_init(void);

void d_1_36params_free(void);

void d_1_36params_init(void);

void d_1_384params_free(void);

void d_1_384params_init(void);

void d_1_3params_free(void);

void d_1_3params_init(void);

void d_1_40params_free(void);

void d_1_40params_init(void);

void d_1_44params_free(void);

void d_1_44params_init(void);

void d_1_48params_free(void);

void d_1_48params_init(void);

void d_1_4params_free(void);

void d_1_4params_init(void);

void d_1_52params_free(void);

void d_1_52params_init(void);

void d_1_56params_free(void);

void d_1_56params_init(void);

void d_1_5params_free(void);

void d_1_5params_init(void);

void d_1_60params_free(void);

void d_1_60params_init(void);

void d_1_64params_free(void);

void d_1_64params_init(void);

void d_1_6params_free(void);

void d_1_6params_init(void);

void d_1_72params_free(void);

void d_1_72params_init(void);

void d_1_7params_free(void);

void d_1_7params_init(void);

void d_1_80params_free(void);

void d_1_80params_init(void);

void d_1_88params_free(void);

void d_1_88params_init(void);

void d_1_8params_free(void);

void d_1_8params_init(void);

void d_1_96params_free(void);

void d_1_96params_init(void);

void d_1_9params_free(void);

void d_1_9params_init(void);

void d_2_104params_free(void);

void d_2_104params_init(void);

void d_2_10params_free(void);

void d_2_10params_init(void);

void d_2_112params_free(void);

void d_2_112params_init(void);

void d_2_11params_free(void);

void d_2_11params_init(void);

void d_2_120params_free(void);

void d_2_120params_init(void);

void d_2_128params_free(void);

void d_2_128params_init(void);

void d_2_12params_free(void);

void d_2_12params_init(void);

void d_2_13params_free(void);

void d_2_13params_init(void);

void d_2_144params_free(void);

void d_2_144params_init(void);

void d_2_14params_free(void);

void d_2_14params_init(void);

void d_2_15params_free(void);

void d_2_15params_init(void);

void d_2_160params_free(void);

void d_2_160params_init(void);

void d_2_16params_free(void);

void d_2_16params_init(void);

void d_2_176params_free(void);

void d_2_176params_init(void);

void d_2_18params_free(void);

void d_2_18params_init(void);

void d_2_192params_free(void);

void d_2_192params_init(void);

void d_2_208params_free(void);

void d_2_208params_init(void);

void d_2_20params_free(void);

void d_2_20params_init(void);

void d_2_224params_free(void);

void d_2_224params_init(void);

void d_2_22params_free(void);

void d_2_22params_init(void);

void d_2_240params_free(void);

void d_2_240params_init(void);

void d_2_24params_free(void);

void d_2_24params_init(void);

void d_2_256params_free(void);

void d_2_256params_init(void);

void d_2_26params_free(void);

void d_2_26params_init(void);

void d_2_288params_free(void);

void d_2_288params_init(void);

void d_2_28params_free(void);

void d_2_28params_init(void);

void d_2_2params_free(void);

void d_2_2params_init(void);

void d_2_30params_free(void);

void d_2_30params_init(void);

void d_2_320params_free(void);

void d_2_320params_init(void);

void d_2_32params_free(void);

void d_2_32params_init(void);

void d_2_352params_free(void);

void d_2_352params_init(void);

void d_2_36params_free(void);

void d_2_36params_init(void);

void d_2_384params_free(void);

void d_2_384params_init(void);

void d_2_3params_free(void);

void d_2_3params_init(void);

void d_2_40params_free(void);

void d_2_40params_init(void);

void d_2_44params_free(void);

void d_2_44params_init(void);

void d_2_48params_free(void);

void d_2_48params_init(void);

void d_2_4params_free(void);

void d_2_4params_init(void);

void d_2_52params_free(void);

void d_2_52params_init(void);

void d_2_56params_free(void);

void d_2_56params_init(void);

void d_2_5params_free(void);

void d_2_5params_init(void);

void d_2_60params_free(void);

void d_2_60params_init(void);

void d_2_64params_free(void);

void d_2_64params_init(void);

void d_2_6params_free(void);

void d_2_6params_init(void);

void d_2_72params_free(void);

void d_2_72params_init(void);

void d_2_7params_free(void);

void d_2_7params_init(void);

void d_2_80params_free(void);

void d_2_80params_init(void);

void d_2_88params_free(void);

void d_2_88params_init(void);

void d_2_8params_free(void);

void d_2_8params_init(void);

void d_2_96params_free(void);

void d_2_96params_init(void);

void d_2_9params_free(void);

void d_2_9params_init(void);

void getParams(double bgn, double Zc, double *infoLen,
               emxArray_int32_T *offsetWeight,
               emxArray_int32_T *columnIndexMap);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for getParams.h
 *
 * [EOF]
 */
