/*
 * File: nrLDPCDecode.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 25-May-2021 16:21:40
 */

#ifndef NRLDPCDECODE_H
#define NRLDPCDECODE_H

/* Include Files */
#include "c_test_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void nrLDPCDecode(const emxArray_real_T *in, double bgn, emxArray_int8_T *out);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for nrLDPCDecode.h
 *
 * [EOF]
 */
