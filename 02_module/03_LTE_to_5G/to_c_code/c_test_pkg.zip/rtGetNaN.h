/*
 * File: rtGetNaN.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 25-May-2021 16:21:40
 */

#ifndef RTGETNAN_H
#define RTGETNAN_H

/* Include Files */
#include "rtwtypes.h"

#ifdef __cplusplus
extern "C" {
#endif

extern real_T rtGetNaN(void);
extern real32_T rtGetNaNF(void);

#ifdef __cplusplus
}
#endif
#endif
/*
 * File trailer for rtGetNaN.h
 *
 * [EOF]
 */
