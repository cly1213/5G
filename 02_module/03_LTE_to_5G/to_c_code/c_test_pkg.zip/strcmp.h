/*
 * File: strcmp.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 25-May-2021 16:21:40
 */

#ifndef STRCMP_H
#define STRCMP_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void b_strcmp(const char a_data[], const int a_size[2], boolean_T b_bool[6]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for strcmp.h
 *
 * [EOF]
 */
