/*
 * File: validatestring.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 25-May-2021 16:21:40
 */

#ifndef VALIDATESTRING_H
#define VALIDATESTRING_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void get_match(const char str_data[], const int str_size[2], char match_data[],
               int match_size[2], double *nmatched);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for validatestring.h
 *
 * [EOF]
 */
